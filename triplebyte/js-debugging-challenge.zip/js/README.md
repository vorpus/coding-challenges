# Javascript debug exercise

To install:

    npm install

To run the already passing tests:

    npm test tests/already_passing_tests.js

To run a failing test:

    npm test tests/failing_test_1.js

